# FT--69906355
Speech Recognition anywhere
Step1:Download the Speech recognition anywhere extension fron chrome app store
Step2:Run the sr.html file
Step3:Go to commods for diffrent speech commands 
